## ----setup, include=FALSE-------------------------------------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ----xaringan-themer, include = FALSE-------------------------------------------------------------------------------
library(xaringanthemer)
style_duo(
  primary_color = "#1F4257", secondary_color = "#F97B64",
  header_font_google = google_font("Josefin Sans"),
  text_font_google   = google_font("Montserrat", "300", "300i"),
  code_font_google   = google_font("Source Code Pro"),
  title_slide_text_color = "#b7e8e5"
)


## ----message=FALSE, warning=FALSE-----------------------------------------------------------------------------------
getwd()
#setwd()


## ----message=FALSE, warning=FALSE-----------------------------------------------------------------------------------
#install.packages("here")
library("here")
here()


## ----message=FALSE, warning=FALSE-----------------------------------------------------------------------------------
df <- read.csv(here("data","core_dataset_clean.csv"))
head(df[,1:3])


## -------------------------------------------------------------------------------------------------------------------
library(here)
df <- read.table(here("data", "core_dataset_clean.csv"), 
                 header = TRUE, sep = ",")
tail(df[,1:3])


## -------------------------------------------------------------------------------------------------------------------
write.csv(df, file = "core_dataset_new.csv")


## -------------------------------------------------------------------------------------------------------------------
save(df, file = "core_dataset_clean.RData")

