## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ----xaringan-themer, include = FALSE------------------------------------
library(xaringanthemer)
style_mono_light(
  base_color = "#23395b",
  header_font_google = google_font("Josefin Sans"),
  text_font_google   = google_font("Montserrat", "300", "300i"),
  code_font_google   = google_font("Source Code Pro"),
  title_slide_text_color = "#e4ecf2"
)


## ----eval=FALSE----------------------------------------------------------
## packs <- c("here", "tidyverse")
## install.packages(packs)

