## ----setup, include=FALSE--------------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ----xaringan-themer, include = FALSE--------------------------------------------------------
library(xaringanthemer)
style_duo(
  primary_color = "#1F4257", secondary_color = "#F97B64",
  header_font_google = google_font("Josefin Sans"),
  text_font_google   = google_font("Montserrat", "300", "300i"),
  code_font_google   = google_font("Source Code Pro"),
  title_slide_text_color = "#b7e8e5"
)


## ----message=FALSE, warning=FALSE------------------------------------------------------------
library(tidyverse)
library(here)
df <- read.csv(here("data","core_dataset_clean.csv"))


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, y = PayRate))

g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, y = PayRate)) +
  geom_point()

g1
  


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, y = PayRate)) +
  geom_bin2d()

g1
  


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, y = PayRate)) +
  geom_density_2d_filled()

g1
  


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, y = PayRate)) +
  geom_density_2d_filled()

ggsave("primer_grafico.png", g1, dpi = 300, width = 12, height= 12, units = "cm")
  


## --------------------------------------------------------------------------------------------
#install.packages("svglite")
ggsave("primer_grafico.svg", g1, dpi = 300, width = 12, height= 12, units = "cm")
  


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, y = PayRate)) +
  geom_point(colour = "blue")

g1
  


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, y = PayRate)) +
  geom_point(aes(colour = "blue"))

g1
  


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, y = PayRate)) +
  geom_point(aes(colour = Sex)) 


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, y = PayRate)) +
  geom_point(aes(colour = Sex),
             size = 4)


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, y = PayRate)) +
  geom_point(aes(colour = Sex),
                 size = 4,
                 alpha = .6)


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate)) +
  geom_point(aes(colour = Sex,
                 shape = MaritalDesc),
                 size = 4,
                 alpha = .8)


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, y = PayRate)) +
  geom_point(aes(colour = Sex),
                 size = 4,
                 alpha = .8) +
  geom_smooth()


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, y = PayRate)) +
  geom_point(aes(colour = Sex),
                 size = 4,
                 alpha = .8) +
  geom_smooth(colour = "black",
              linetype = "dotted",
              size = 2,
              span = 0.3)


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, y = PayRate)) +
  geom_point(aes(colour = Sex),
                 size = 4,
                 alpha = .8) +
  geom_smooth(colour = "black",
              size = 2,
              span = 0.3,
              method = "lm")


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate)) +
  geom_point(aes(colour = Sex),
                 size = 4,
                 alpha = .8) +
  geom_smooth(colour = "black",
              size = 2,
              span = 0.3,
              method = "lm") +
  facet_grid(~Sex)


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate)) +
  geom_point(aes(colour = Sex),
             size = 4,
             alpha = .8) +
  geom_smooth(aes(group = Sex),
              colour = "black",
              size = 2,
              span = 0.3,
              method = "lm")


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate,
             group = Sex,
             colour = Sex)) +
  geom_point(size = 4,
             alpha = .8) +
  geom_smooth(colour = "black",
              size = 2,
              span = 0.3,
              method = "lm")


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate,
             group = Sex,
             colour = Sex)) +
  geom_point(size = 4,
             alpha = .8) +
  geom_smooth(colour = "black",
              size = 2,
              span = 0.3,
              method = "lm",
              fullrange = TRUE)


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate,
             group = Sex)) +
  geom_point(aes(colour = Sex),
             size = 4,
             alpha = .8) +
  geom_smooth(aes(colour = Sex),
              size = 2,
              span = 0.3,
              method = "lm",
              fullrange = TRUE) +
  theme_classic()


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate,
             group = Sex)) +
  geom_point(aes(colour = Sex),
             size = 4,
             alpha = .8) +
  geom_smooth(aes(colour = Sex),
              size = 2,
              span = 0.3,
              method = "lm",
              fullrange = TRUE) +
  theme_dark()


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate,
             group = Sex)) +
  geom_point(aes(colour = Sex),
             size = 4,
             alpha = .8) +
  geom_smooth(aes(colour = Sex),
              size = 2,
              span = 0.3,
              method = "lm",
              fullrange = TRUE) +
  theme_minimal()


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate,
             group = Sex)) +
  geom_point(aes(colour = Sex),
             size = 4,
             alpha = .8) +
  geom_smooth(colour = "black",
              size = 2,
              span = 0.3,
              method = "lm",
              fullrange = TRUE) +
  theme_minimal()+
  xlim(25, 70) +
  ylim(0,100)


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate,
             group = Sex)) +
  geom_point(aes(colour = Sex),
             size = 4,
             alpha = .8) +
  geom_smooth(aes(colour = Sex),
              size = 2,
              span = 0.3,
              method = "lm",
              fullrange = TRUE) +
  theme_minimal() +
  xlim(25, 70) +
  ylim(0,100) +
  xlab("Edad de los trabajadores") +
  ylab("Salario por hora")


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate,
             group = Sex)) +
  geom_point(aes(colour = Sex),
             size = 4,
             alpha = .8) +
  geom_smooth(aes(colour = Sex),
              size = 2,
              span = 0.3,
              method = "lm",
              fullrange = TRUE) +
  theme_minimal() +
  xlim(25, 70) +
  ylim(0,100) +
  xlab("Edad de los trabajadores") +
  ylab("Salario por hora") +
  scale_color_brewer(palette = "Set1") 


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate,
             group = Sex)) +
  geom_point(aes(colour = Sex),
             size = 4,
             alpha = .8) +
  geom_smooth(aes(colour = Sex),
              size = 2,
              span = 0.3,
              method = "lm",
              fullrange = TRUE) +
  theme_minimal() +
  xlim(25, 70) +
  ylim(0,100) +
  xlab("Edad de los trabajadores") +
  ylab("Salario por hora") +
  scale_color_brewer(palette = "Dark2")


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
#install.packages("ggthemes")
library(ggthemes)

g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate,
             group = Sex)) +
  geom_point(aes(colour = Sex),
             size = 4,
             alpha = .8) +
  geom_smooth(aes(colour = Sex),
              size = 2,
              span = 0.3,
              method = "lm",
              fullrange = TRUE) +
  theme_minimal() +
  xlim(25, 70) +
  ylim(0,100) +
  xlab("Edad de los trabajadores") +
  ylab("Salario por hora") +
  scale_color_tableau()


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate,
             group = Sex)) +
  geom_point(aes(colour = Sex),
             size = 4,
             alpha = .8) +
  geom_smooth(aes(colour = Sex),
              size = 2,
              span = 0.3,
              method = "lm",
              fullrange = TRUE) +
  theme_minimal() +
  xlim(25, 70) +
  ylim(0,100) +
  xlab("Edad de los trabajadores") +
  ylab("Salario por hora") +
  scale_color_manual(values = c("#008280FF", "#631879FF"))


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate,
             group = Sex)) +
  geom_point(aes(colour = Sex),
             size = 4,
             alpha = .8) +
  geom_smooth(aes(colour = Sex),
              size = 2,
              span = 0.3,
              method = "lm",
              fullrange = TRUE) +
  theme_minimal() +
  xlim(25, 70) +
  ylim(0,100) +
  xlab("Edad de los trabajadores") +
  ylab("Paga por hora") +
  labs(title = "Relacción entre salario por hora y edad",
       subtitle = "Modelos de relación lineal para género por separado",
       caption = "Es increíble lo que se puede conseguir con 8 líneas de código")


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Age, 
             y = PayRate,
             group = Sex)) +
  geom_point(aes(colour = Sex),
             size = 4,
             alpha = .8) +
  geom_smooth(aes(colour = Sex),
              size = 2,
              span = 0.3,
              method = "lm",
              fullrange = TRUE) +
  theme_minimal() +
  xlab("Edad de los trabajadores") +
  ylab("Paga por hora") +
  labs(title = "Relacción entre salario por hora y edad",
       subtitle = "Modelos de relación lineal para género por separado",
       caption = "Es increíble lo que se puede conseguir con 8 líneas de código") +
  theme(axis.title = element_text(size = 15,
                                 face = "bold"))


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = Department, 
             y = PayRate)) +
  geom_point()


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  filter(Department != "Executive Office") %>% 
  ggplot(aes(x = Department, 
             y = PayRate)) +
  geom_boxplot()


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  filter(Department != "Executive Office") %>% 
  ggplot(aes(x = Department, 
             y = PayRate)) +
  geom_boxplot(aes(fill = Department))


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  filter(Department != "Executive Office") %>% 
  ggplot(aes(x = reorder(Department, PayRate),
             y = PayRate)) +
  geom_boxplot(aes(fill = Department),
               alpha = .8)


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  filter(Department != "Executive Office") %>% 
  ggplot(aes(x = PayRate)) +
  geom_density(aes(fill = Department),
               alpha = .8)


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
#install.packages(ggridges)

library(ggridges)

g1 <- df %>% 
  filter(Department != "Executive Office") %>% 
  ggplot(aes(x = PayRate, y = Department)) +
  geom_density_ridges(aes(fill = Department),
               alpha = .8)


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  filter(Department != "Executive Office") %>% 
  ggplot(aes(x = PayRate)) +
    geom_density(aes(fill = Department), alpha = .8) +
    facet_wrap(~ Department, scale = "free_y")


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  filter(Department != "Executive Office") %>% 
  ggplot(aes(x = PayRate)) +
    geom_histogram(aes(fill = Department), alpha = .8) +
    facet_wrap(~ Department, scale = "free_y")


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  filter(Department != "Executive Office") %>% 
  ggplot(aes(x = PayRate)) +
    geom_histogram(aes(fill = Department), alpha = .8,
                   bins = 50) +
    facet_wrap(~ Department, scale = "free_y")


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  filter(Department != "Executive Office") %>% 
  ggplot(aes(x = Department, 
             y = PayRate)) +
  stat_summary(fun.data = "mean_cl_boot")


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  filter(Department != "Executive Office") %>% 
  ggplot(aes(x = Department, 
             y = PayRate)) +
  stat_summary(fun.data = "mean_cl_boot",
               size = 1.5,
               aes(colour = Department))


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  filter(Department != "Executive Office") %>% 
  ggplot(aes(x = Department, 
             y = PayRate)) +
  stat_summary(fun.data = "mean_cl_boot",
               size = 1.5,
               aes(colour = Department)) +
  geom_point(alpha = .5)


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  filter(Department != "Executive Office") %>% 
  ggplot(aes(x = Department, 
             y = PayRate)) +
  
  geom_point(alpha = .5) +
  
  stat_summary(fun.data = "mean_cl_boot",
               size = 1.5,
               aes(colour = Department))


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  filter(Department != "Executive Office") %>% 
  ggplot(aes(x = Department, 
             y = PayRate)) +
  geom_jitter(alpha = .5,
              size = 1.5) +
    stat_summary(fun.data = "mean_cl_boot",
               size = 1.5,
               aes(colour = Department)) 


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  filter(Department != "Executive Office") %>% 
  ggplot(aes(x = Department, 
             y = PayRate)) +
  geom_jitter(aes(colour = Department),
              alpha = .2,
              width = .3,
              size = 3) +
  
   stat_summary(fun.data = "mean_cl_boot",
               size = 1.5,
               aes(colour = Department)) +
  theme_minimal() + 
  ylab("Departamento") + 
  xlab("Salario por hora") +
  labs(title = "Salario por hora según el departamento",
       subtitle = "Salarios ofrecidos en euros",
       caption = "Datos obtenidos en empresa X en 2020")


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = RaceDesc)) +
  geom_bar()



## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = RaceDesc)) +
  geom_bar(aes(fill = RaceDesc))


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = RaceDesc,
             fill = MaritalDesc)) +
  geom_bar()


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = RaceDesc,
             fill = MaritalDesc)) +
  geom_bar(position = "dodge")


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = RaceDesc,
             fill = MaritalDesc)) +
    geom_bar(position = "dodge")+
    coord_flip()


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = RaceDesc,
             fill = MaritalDesc)) +
  geom_bar(position = "fill")


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
g1 <- df %>% 
  ggplot(aes(x = RaceDesc,
             fill = MaritalDesc)) +
  geom_bar(position = "fill") +
  scale_fill_tableau()


## --------------------------------------------------------------------------------------------
g1


## --------------------------------------------------------------------------------------------
library(plotly)


## --------------------------------------------------------------------------------------------
ggplotly(g1)

