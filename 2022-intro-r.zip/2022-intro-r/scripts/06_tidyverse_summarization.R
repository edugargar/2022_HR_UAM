## ----setup, include=FALSE--------------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ----xaringan-themer, include = FALSE--------------------------------------------------------
library(xaringanthemer)
style_duo(
  primary_color = "#1F4257", secondary_color = "#F97B64",
  header_font_google = google_font("Josefin Sans"),
  text_font_google   = google_font("Montserrat", "300", "300i"),
  code_font_google   = google_font("Source Code Pro"),
  title_slide_text_color = "#b7e8e5"
)


## ----message=FALSE, warning=FALSE------------------------------------------------------------
library(tidyverse)
library(here)
df <- read.csv(here("data","core_dataset_clean.csv"))


## --------------------------------------------------------------------------------------------
summary(df[,1:4])


## ----message=FALSE, warning=FALSE------------------------------------------------------------
#install.packages("summarytools")
library("summarytools")
view(dfSummary(df))


## --------------------------------------------------------------------------------------------
df3 <- df %>% 
  mutate (PayRate_ten = PayRate*10, 
          Age_month = Age * 12)
glimpse(df3$PayRate)  
glimpse(df3$PayRate_ten)  


## --------------------------------------------------------------------------------------------
df4 <- df %>% 
  mutate (PayRate_scaled = scale(PayRate), 
          Age_centered = Age - mean(Age))
glimpse(df4$Age)  
glimpse(df4$Age_centered)  


## --------------------------------------------------------------------------------------------
df5 <- df %>% 
  mutate (Sex_f = as.character(Sex))
          
str(df5$Sex)
str(df5$Sex_f)


## --------------------------------------------------------------------------------------------
df6 <- df5 %>% 
  mutate (Sex_recode = fct_recode(Sex_f,
                                  "Woman" = "Female",
                                  "Man" = "Male"))
levels(df6$Sex_f)
levels(df6$Sex_recode)


## --------------------------------------------------------------------------------------------
df7 <- df6 %>% 
  mutate (Sex_relevel = fct_relevel(Sex_recode, "Male", "Female"))

levels(df7$Sex_recode)
levels(df7$Sex_relevel)



## --------------------------------------------------------------------------------------------
df8 <- df %>% 
  mutate (offices = case_when(
      Department == "Admin Offices" |  Department == "IT/IS" ~ "office",
      Department == "Executive Office" ~  "executive",
      T ~ "other"
      ))

table(df8$Department, df8$offices)


## --------------------------------------------------------------------------------------------
df9 <- df %>% 
  mutate (offices_joven = case_when(
         Department == "Admin Offices" |  Age < 28 ~ "office_joven",
         T ~ "other"
         ))

table(df9$offices_joven, df9$offices)


## ----echo=TRUE-------------------------------------------------------------------------------
prop.table(table(df9$offices_joven, df9$offices))


## ----echo=TRUE-------------------------------------------------------------------------------
round( prop.table (table (df9$offices_joven, df9$offices)), 2)


## ----echo=TRUE-------------------------------------------------------------------------------
df10 <- df %>% 
  mutate (offices_joven = case_when(
         Department == "Admin Offices" |  Age < 28 ~ "office_joven",
         T ~ "other")) %>%
  count(offices_joven) %>% 
  mutate(freq = prop.table(n),
         freq = round(freq,2))
df10


## --------------------------------------------------------------------------------------------
df11 <- df %>%
  summarise (medias = mean(PayRate))


## --------------------------------------------------------------------------------------------
df12 <- df %>%
  group_by(Position) %>% 
  summarise (medias = mean(PayRate))

glimpse(df12)


## --------------------------------------------------------------------------------------------
df13 <- df %>%
  group_by(Position) %>% 
  mutate (medias = mean(PayRate))

glimpse(df13)


## --------------------------------------------------------------------------------------------
df14 <- df %>%
  group_by(Position) %>% 
  summarise (medias = mean(PayRate)) %>% 
  arrange(medias)

glimpse(df14)


## --------------------------------------------------------------------------------------------
df15 <- df %>%
  group_by(Position) %>% 
  summarise (medias = mean(PayRate)) %>% 
  arrange(desc(medias))

glimpse(df15)


## --------------------------------------------------------------------------------------------
fun1 = function(x) {
    x = x +10 
    return(x)
    } 

df16 <- df %>%
  summarise (
      PayRate = PayRate,
      diezmas = fun1(PayRate)
      )

glimpse(df16)


## --------------------------------------------------------------------------------------------
df17 <- df %>%
  group_by(Position) %>% 
  slice_head(n = 2)

