## ----setup, include=FALSE--------------------------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)


## ----xaringan-themer, include = FALSE--------------------------------------------------------
library(xaringanthemer)
style_duo(
  primary_color = "#1F4257", secondary_color = "#F97B64",
  header_font_google = google_font("Josefin Sans"),
  text_font_google   = google_font("Montserrat", "300", "300i"),
  code_font_google   = google_font("Source Code Pro"),
  title_slide_text_color = "#b7e8e5"
)


## ----message=FALSE, warning=FALSE------------------------------------------------------------
library(tidyverse)
library(here)
df <- read.csv(here("data","core_dataset_clean.csv"))


## --------------------------------------------------------------------------------------------
df1 <- subset(df, MaritalDesc == "Single")
head(df1$MaritalDesc)


## --------------------------------------------------------------------------------------------
df1 <- filter(df, MaritalDesc == "Single")
head(df1$MaritalDesc)


## --------------------------------------------------------------------------------------------
df1 <- df %>% 
  filter(MaritalDesc == "Single")

head(df1$MaritalDesc)


## --------------------------------------------------------------------------------------------
df1 <- df %>% 
  filter(MaritalDesc == "Single" & 
           Age >25 & 
           Sex == "Male")

glimpse(df1)


## --------------------------------------------------------------------------------------------
df1 <- df %>% 
  filter(MaritalDesc == "Single"| Age  < 25 )


## --------------------------------------------------------------------------------------------
df1 <- df %>% 
  filter(between(Age, 25, 35))


## --------------------------------------------------------------------------------------------
df1 <- df %>% 
  filter(
      (MaritalDesc == "Married" ) | (MaritalDesc == "Single" & Sex == "Female")
  )


## --------------------------------------------------------------------------------------------
df1 <- df %>% 
  filter(MaritalDesc == "Single" & 
           Age >25 & 
           Sex == "Male") %>% 
  select(c(EmployeeName, State, Age))


## --------------------------------------------------------------------------------------------
df1 <- df %>% 
  filter(MaritalDesc == "Single" & 
           Age >25 & 
           Sex == "Male") %>% 
  select(c(-State, -Age))


## --------------------------------------------------------------------------------------------
df1 <- df %>% 
    select(starts_with("Employ"))


## --------------------------------------------------------------------------------------------
df1 <- df %>% 
    select(contains("Desc"))


## --------------------------------------------------------------------------------------------
df1 <- df %>% 
  arrange(Age) %>% 
  rename("Edad" = "Age")


## --------------------------------------------------------------------------------------------
colnames(df1)
colnames(df1)[3]<-c("Edad2") 
colnames(df1)


## --------------------------------------------------------------------------------------------
df2 <- read.csv(here("data","core_dataset_clean_extended.csv"))


## --------------------------------------------------------------------------------------------
df_total <- bind_rows(df, df2)


## --------------------------------------------------------------------------------------------
df_incompleto <- df %>% 
    select(-Age)
df_minus_age <- bind_rows(df_incompleto, df2)


## --------------------------------------------------------------------------------------------
Age <- df %>% 
    select("Age") %>% 
    rename("Age_sola" = "Age") 

df_age <- bind_cols(df, Age)
colnames(df_age)


## --------------------------------------------------------------------------------------------
df_perf <- read.csv(here("data","core_dataset_clean_performance.csv"))


## --------------------------------------------------------------------------------------------
df_inner <- inner_join(df_total, df_perf, by = "EmployeeName") %>% 
    view()


## --------------------------------------------------------------------------------------------
df_inner <- inner_join(df_total, df_perf, by = c("EmployeeName" = "EmployeeSource")) %>% 
    view()


## --------------------------------------------------------------------------------------------
df_full <- full_join(df_total, df_perf, by = c("EmployeeName" = "EmployeeSource")) %>% 
    view()


## --------------------------------------------------------------------------------------------
df_full <- full_join(df_total, df_perf, by = c("EmployeeName")) %>% 
    view()


## --------------------------------------------------------------------------------------------
df_left <- left_join(df, df_perf, by = c("EmployeeName"))
df_right <- right_join(df, df_perf, by = c("EmployeeName"))


## --------------------------------------------------------------------------------------------
df_left_completo <- df_left %>% 
    drop_na()


## --------------------------------------------------------------------------------------------
df %>% 
  summarise(across(everything(), ~ sum(is.na(.x))))

